


function sortTable() {
   table.innerHTML = "";
   
   var newTableData = TABLE_DATA.sort((a,b) => {
       return a.id - b.id
   })
    
   

   for (let i = 0; i < newTableData.length; i++) { 

      for (let j = i + 1; j < newTableData.length; j++) {

         if (Number(newTableData[i].id) > Number(newTableData[j].id)){
            temp = newTableData[i].id;
            newTableData[i].id = newTableData[j].id;
            newTableData[j].id = temp;
            
        
         }
         
         
         
      
      }
   }
   
   
   for (var i = 0; i < newTableData.length; i++) {
      insertDataInTable(newTableData[i])
       
   }
}

function startRandomTable() {
   randomGenrator = true
 }

function insertDataInTable(data) {
   // code
   var TableRow = document.createElement('tr')
   var id = document.createElement('td')
   var name_data = document.createElement('td')
   var thumbnailUrl = document.createElement('td')
   var price = document.createElement('td')
   
   id.innerHTML = data.id
   name_data.innerHTML = data.name
   thumbnailUrl.innerHTML = data.thumbnailUrl
   price.innerHTML = data.price
   
   TableRow.appendChild(id)
   TableRow.appendChild(thumbnailUrl)
   TableRow.appendChild(name_data)
   TableRow.appendChild(price)
   table.appendChild(TableRow)
   
}
var table = document.getElementById('myTableBody')
// var randomGenrator = false

for (var i = 0; i < TABLE_DATA.length; i++) {
     insertDataInTable(TABLE_DATA[i])
}

function stopRandomTable() {
   randomGenrator = false
   console.log(randomGenrator)
}

function timerFunction() {
   if (randomGenrator) {
      console.log('timeout start')
      console.log(randomGenrator)
      table.innerHTML = ""
      var newTableData = TABLE_DATA
      var oldIndex = []
      console.log('while start', oldIndex.length <= 10, oldIndex.length === 10)
      var loop = true
      while (loop) {
         var newIndex = Math.floor(Math.random() * newTableData.length)
         console.log(oldIndex, oldIndex.length)
         if (oldIndex.length >= 0) {
            var flag = false
            console.log('if run', newIndex)
            for (var i = 0; i < oldIndex.length; i++) {
               if (newIndex == oldIndex[i]) {
                  flag = true
               }
            }
            console.log('flag check', flag)
            if (flag === false) {
               insertDataInTable(newTableData[newIndex])
               oldIndex.push(newIndex)
            }
         } else {
            // console.log('else run',oldIndex.length>0,newIndex)
            insertDataInTable(newTableData[newIndex])
            oldIndex.push(newIndex)
         }
         if (oldIndex.length === 10) loop = false
      }
      console.log('while end')
   }
}
setInterval(timerFunction, 2000)

// ali